setwd("C:\\Users\\USER\\OneDrive\\Desktop\\it24102121\\lab9_it24102121")
# Generate 25 random numbers (baking times) from N(mean=45, sd=2)
baking_time <- rnorm(25, mean = 45, sd = 2)

print("Generated Random Sample (Baking Times):")
print(baking_time)

# Perform the one-sample t-test
test_result <- t.test(
  baking_time, 
  mu = 46,              # Hypothesized mean under H0
  alternative = "less"  # Specifies H1: mu < 46
)
print("Hypothesis Test Results:")
print(test_result)
print(paste("Test Statistic (t):", test_result$statistic))
print(paste("P-value:", test_result$p.value))
print("Confidence Interval:")
print(test_result$conf.int)
