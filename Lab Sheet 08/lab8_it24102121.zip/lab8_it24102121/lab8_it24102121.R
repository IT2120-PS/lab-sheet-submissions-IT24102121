setwd("C:\\Users\\USER\\OneDrive\\Desktop\\it24102121\\lab8_it24102121")
data <- read.table("Exercise - LaptopsWeights.txt", header=TRUE)
Weight <- data$`Weight.kg.` 

# Define parameters for sampling
num_samples <- 25
sample_size <- 6

pop_mean <- mean(Weight)
pop_sd <- sd(Weight)

print("--- 1: Population Parameters ---")
print(paste("Population Mean (mu):", round(pop_mean, 4)))
print(paste("Population Standard Deviation (sigma):", round(pop_sd, 4)))


# Initialize vectors to store sample statistics
sample_means <- numeric(num_samples)
sample_sds <- numeric(num_samples)

for (i in 1:num_samples) {
  # Draw a random sample of size 6 with replacement from the population
  current_sample <- sample(Weight, size = sample_size, replace = TRUE)
  
  # Calculate sample mean and standard deviation and store them
  sample_means[i] <- mean(current_sample)
  sample_sds[i] <- sd(current_sample)
}
print("--- 2: Sample Statistics ---")
print("Sample Means (Vector of 25 values):")
print(sample_means)
print("Sample Standard Deviations (Vector of 25 values):")
print(sample_sds)

mean_of_sample_means <- mean(sample_means)
sd_of_sample_means <- sd(sample_means)
theoretical_sd_of_means <- pop_sd / sqrt(sample_size)

print("--- 3: Sampling Distribution Parameters ---")
print(paste("Mean of Sample Means (E[X̄]):", round(mean_of_sample_means, 4)))
print(paste("Standard Deviation of Sample Means (Experimental SE):", round(sd_of_sample_means, 4)))
print(paste("Theoretical Standard Error (σ / sqrt(6)):", round(theoretical_sd_of_means, 4)))

print("--- Relationship Statement ---")
print("1. Relationship of Means:")
print(paste("   The Mean of the Sample Means (", round(mean_of_sample_means, 4), ") is expected to be approximately equal to the Population Mean (", round(pop_mean, 4), "). This demonstrates that the sample mean (X̄) is an **unbiased estimator** of the population mean (μ)."))

print("2. Relationship of Standard Deviations:")
print(paste("   The Standard Deviation of the Sample Means (", round(sd_of_sample_means, 4), ") is expected to be approximately equal to the **Theoretical Standard Error** (Population SD / sqrt(n)) (", round(theoretical_sd_of_means, 4), "). This confirms the relationship described by the Central Limit Theorem concerning the spread of the sampling distribution."))
