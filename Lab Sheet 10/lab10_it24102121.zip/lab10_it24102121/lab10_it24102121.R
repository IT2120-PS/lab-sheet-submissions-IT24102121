setwd("C:\\Users\\USER\\OneDrive\\Desktop\\it24102121\\lab10_it24102121")
data <- read.csv("Data.csv", header = TRUE, row.names = 1)
data
snacks <- c(120, 95, 85, 100) 
chisq.test(snacks)
